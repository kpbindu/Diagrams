package com.ubs.demo.wrapper;

	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.core.ParameterizedTypeReference;
	import org.springframework.http.HttpEntity;
	import org.springframework.http.HttpHeaders;
	import org.springframework.http.HttpMethod;
	import org.springframework.http.MediaType;
	import org.springframework.stereotype.Component;
	import org.springframework.web.client.RestTemplate;

	import graphql.schema.DataFetcher;
	import com.ubs.demo.vo.Asset;

	@Component
	public class GraphQLDataFetcher {

		private final String REST_URL = "https://neo.ubs.com/api/evidence-lab/appMonitor/assets";

		@Autowired
		private RestTemplate restTemplate;

		public DataFetcher<List<Asset>> getAssetList() {
			return dataFetchingEnvironment -> {
				return restTemplate
						.exchange(REST_URL, HttpMethod.GET, null, new ParameterizedTypeReference<List<Asset>>() {
						}).getBody();
			};
		}

		public DataFetcher<Asset> getAssetById() {
			return dataFetchingEnvironment -> {
				String id = dataFetchingEnvironment.getArgument("id");

				return restTemplate.getForObject(REST_URL + "/" + id, Asset.class);
			};
		}

		public DataFetcher<String> addAsset() {
			return dataFetchingEnvironment -> {
				String name = dataFetchingEnvironment.getArgument("name");
				String url = dataFetchingEnvironment.getArgument("url");

				Asset website = new Asset();
				website.setName(name);
				website.setUrl(url);

				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);

				HttpEntity<Asset> entity = new HttpEntity<>(website, headers);

				return restTemplate.postForObject(REST_URL, entity, String.class);
			};
		}

		public DataFetcher<String> updateAsset() {
			return dataFetchingEnvironment -> {
				String id = dataFetchingEnvironment.getArgument("id");
				String name = dataFetchingEnvironment.getArgument("name");
				String url = dataFetchingEnvironment.getArgument("url");

				Asset website = new Asset(Integer.parseInt(id), name, url);

				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);

				HttpEntity<Asset> entity = new HttpEntity<>(website, headers);

				return restTemplate.exchange(REST_URL, HttpMethod.PUT, entity, new ParameterizedTypeReference<String>() {
				}).getBody();
			};
		}

		public DataFetcher<String> deleteAsset() {
			return dataFetchingEnvironment -> {
				String id = dataFetchingEnvironment.getArgument("id");

				Asset website = new Asset();
				website.setId(Integer.parseInt(id));

				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);

				HttpEntity<Asset> entity = new HttpEntity<>(website, headers);

				return restTemplate.exchange(REST_URL, HttpMethod.DELETE, entity, new ParameterizedTypeReference<String>() {
				}).getBody();
			};
		}
		

}
