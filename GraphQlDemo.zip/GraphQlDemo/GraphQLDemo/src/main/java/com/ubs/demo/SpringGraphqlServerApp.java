package com.ubs.demo;



	import org.springframework.boot.SpringApplication;
	import org.springframework.boot.autoconfigure.SpringBootApplication;

	@SpringBootApplication(scanBasePackages = "com.ubs.demo")
	public class SpringGraphqlServerApp {

		public static void main(String[] args) {
			SpringApplication.run(SpringGraphqlServerApp.class, args);
		}

	}


	